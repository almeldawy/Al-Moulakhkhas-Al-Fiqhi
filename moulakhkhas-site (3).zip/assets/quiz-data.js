/* Questions du quiz (page quiz.html). Ajoutez-en autant que vous voulez. answer = index de la bonne option (0 = première). */
window.QUIZ = [
  {
    question: "Quelle est la règle de base concernant l'eau de pluie pour la purification ?",
    options: ["Seulement pour l'Istinjâ'", 'Elle est pure et purifiante (Tahûr)', "Elle nécessite d'être bouillie", "Elle n'est pas utilisable"],
    answer: 1,
    explanation: "L'eau de pluie est considérée comme Tahûr (pure et purifiante), sur la base de la parole d'Allah (Sourate Al-Furqân, V.48)."
  },
  {
    question: "Quelle est la durée d'essuyage sur les chaussettes (Khuffayn) pour un résident ?",
    options: ['3 jours et 3 nuits', '1 jour et 1 nuit (24 heures)', '7 jours', "Tant qu'on ne les retire pas"],
    answer: 1,
    explanation: "Selon le hadith rapporté par Muslim, la durée est d'un jour et une nuit pour le résident et de trois jours et trois nuits pour le voyageur."
  },
  {
    question: "Quel est le taux standard de la Zakât sur l'or, l'argent et le capital financier ?",
    options: ['10 %', '5 %', '2,5 %', '1 %'],
    answer: 2,
    explanation: "Le taux est de 2,5 % (un quarantième) lorsque le Nisâb et le Hawl sont atteints."
  }
];
